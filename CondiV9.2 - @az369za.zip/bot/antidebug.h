#define ANTIDEBUG_H

void antidebug(void);
